import UIKit

var greeting = "Hello, playground"

//bool

var flag = false

if flag == true {
    print("flag is true")
} else {
    print("flag is false")
}

if flag {
    print("flag is true")
} else {
    print("flag is false")
}


var oneFlag = flag == true ? 3 : 2


var array: [String] = []
var intArray: [Int] = []

var emptyArr = [String]()

//let item1 = array[safe at: 0]
//!array.isEmpty
array = ["x"]
if array.count > 0 {
   // let item1 = array[0]
}

let firstItem = array.first

let _ = array[0]


for item in array {
    
}

for i in 0..<5{
    print(i)
}

for index in stride(from: 10, to: 1, by: -1){
    print(index)
}
